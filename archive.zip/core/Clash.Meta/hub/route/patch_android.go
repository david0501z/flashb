//go:build android && cmfa

package route

func init() {
	SetEmbedMode(true) // set embed mode default
}
