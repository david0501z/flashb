//go:build mips || mipsle

package executor

const concurrentCount = 1
