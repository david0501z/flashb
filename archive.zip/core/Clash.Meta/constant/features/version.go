package features

var WindowsMajorVersion uint32
var WindowsMinorVersion uint32
var WindowsBuildNumber uint32
