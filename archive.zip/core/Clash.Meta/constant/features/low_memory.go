//go:build with_low_memory

package features

const WithLowMemory = true
