//go:build !android

package features

const Android = false
